@extends('layouts.auth')

@section('title', 'Select Payment')
@section('subtitle', "You've selected the {$plan->name} package.")

@section('content')

<div class="bg-gray-50 dark:bg-white/5 border border-dashed border-gray-300 dark:border-white/20 rounded-2xl p-6 mb-8 flex justify-between items-center">
    <span class="text-gray-500 dark:text-[#94A3B8]">Total Amount:</span>
    <span class="text-2xl font-bold text-[#FF2D20]">${{ number_format($plan->price, 2) }}</span>
</div>

<form action="{{ route('payment.process') }}" method="POST">
    @csrf
    <input type="hidden" name="plan_id" value="{{ $plan->id }}">
    
    <label class="block text-gray-500 dark:text-[#94A3B8] text-sm mb-4">Choose Payment Method:</label>

    <div class="grid gap-4 mb-8">
        <!-- Stripe -->
        <label class="flex items-center gap-4 bg-gray-50 dark:bg-black/30 p-4 rounded-xl border border-gray-200 dark:border-white/10 cursor-pointer transition-all duration-300 hover:border-[#FF2D20] has-[:checked]:border-[#FF2D20] has-[:checked]:bg-red-50 dark:has-[:checked]:bg-red-500/10">
            <input type="radio" name="gateway" value="stripe" checked class="w-5 h-5 text-[#FF2D20] focus:ring-[#FF2D20] dark:bg-black/50 dark:border-white/20">
            <div class="flex items-center gap-3 text-gray-900 dark:text-white font-medium">
                <i data-feather="credit-card" class="w-5 text-gray-400"></i>
                <span>Credit / Debit Card (Stripe)</span>
            </div>
        </label>

        <!-- Duitku -->
        <label class="flex items-center gap-4 bg-gray-50 dark:bg-black/30 p-4 rounded-xl border border-gray-200 dark:border-white/10 cursor-pointer transition-all duration-300 hover:border-[#FF2D20] has-[:checked]:border-[#FF2D20] has-[:checked]:bg-red-50 dark:has-[:checked]:bg-red-500/10">
            <input type="radio" name="gateway" value="duitku" class="w-5 h-5 text-[#FF2D20] focus:ring-[#FF2D20] dark:bg-black/50 dark:border-white/20">
            <div class="flex items-center gap-3 text-gray-900 dark:text-white font-medium">
                <i data-feather="smartphone" class="w-5 text-gray-400"></i>
                <span>QRIS / Bank Transfer (Duitku)</span>
            </div>
        </label>

        <!-- PayPal -->
        <label class="flex items-center gap-4 bg-gray-50 dark:bg-black/30 p-4 rounded-xl border border-gray-200 dark:border-white/10 cursor-pointer transition-all duration-300 hover:border-[#FF2D20] has-[:checked]:border-[#FF2D20] has-[:checked]:bg-red-50 dark:has-[:checked]:bg-red-500/10">
            <input type="radio" name="gateway" value="paypal" class="w-5 h-5 text-[#FF2D20] focus:ring-[#FF2D20] dark:bg-black/50 dark:border-white/20">
            <div class="flex items-center gap-3 text-gray-900 dark:text-white font-medium">
                <i data-feather="globe" class="w-5 text-gray-400"></i>
                <span>PayPal (Global)</span>
            </div>
        </label>
    </div>

    <button type="submit" class="btn-primary w-full shadow-lg">Complete Payment</button>
</form>

<div class="text-center mt-8 text-sm">
    <a href="{{ route('home') }}" class="text-gray-500 dark:text-[#94A3B8] hover:text-[#FF2D20] transition-colors no-underline">Cancel and return home</a>
</div>
@endsection
