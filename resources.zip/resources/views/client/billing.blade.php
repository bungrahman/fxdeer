<!DOCTYPE html>
<html lang="en" x-data="{ darkMode: localStorage.getItem('darkMode') === 'true', sidebarOpen: false }" x-init="$watch('darkMode', val => localStorage.setItem('darkMode', val))" :class="{ 'dark': darkMode }">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Billing History - FXDeer</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/feather-icons"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body :class="{ 'overflow-hidden md:overflow-auto': sidebarOpen }">
    <!-- Mobile Sidebar Overlay -->
    <div x-show="sidebarOpen" x-transition.opacity class="fixed inset-0 bg-black/50 z-30 md:hidden" @click="sidebarOpen = false"></div>

    <div class="sidebar" :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'">
        <div class="flex items-center justify-between mb-8">
            <a href="/" class="logo flex items-center gap-2"><i data-feather="terminal" class="text-[#FF2D20]"></i> FXDeer</a>
            <button @click="sidebarOpen = false" class="md:hidden text-gray-500 hover:text-gray-900 dark:hover:text-white">
                <i data-feather="x"></i>
            </button>
        </div>

        <div class="nav-links flex flex-col gap-2">
            <a href="{{ route('client.dashboard') }}" class="nav-link"><i data-feather="grid"></i> Dashboard</a>
            <a href="{{ route('client.pipelines') }}" class="nav-link"><i data-feather="settings"></i> My Pipelines</a>
            <a href="{{ route('client.billing') }}" class="nav-link active"><i data-feather="credit-card"></i> Billing</a>
        </div>
        
        <div class="mt-auto">
            <form action="{{ route('logout') }}" method="POST">
                @csrf
                <button type="submit" class="nav-link w-full border-none bg-transparent cursor-pointer text-left">
                    <i data-feather="log-out"></i> Logout
                </button>
            </form>
        </div>
    </div>

    <div class="main-content">
        <!-- Top Navigation Area for Mobile & Dark Mode -->
        <div class="flex justify-between items-center mb-8">
            <div class="flex items-center gap-4">
                <button @click="sidebarOpen = true" class="md:hidden p-2 rounded-lg bg-white dark:bg-[#17171a]/70 border border-gray-200 dark:border-white/10 text-gray-600 dark:text-gray-300">
                    <i data-feather="menu"></i>
                </button>
                <div class="hidden md:block">
                    <h1 class="text-2xl font-bold">Billing History</h1>
                </div>
            </div>

            <button @click="darkMode = !darkMode" class="p-2 rounded-full bg-white dark:bg-[#17171a]/70 border border-gray-200 dark:border-white/10 text-gray-600 dark:text-gray-300 transition-colors hover:bg-gray-50 dark:hover:bg-white/10">
                <i x-show="!darkMode" data-feather="moon" style="display: none;" class="w-5 h-5"></i>
                <i x-show="darkMode" data-feather="sun" style="display: none;" class="w-5 h-5"></i>
            </button>
        </div>

        <div class="mb-8 md:hidden">
            <h1 class="text-2xl font-bold">Billing History</h1>
            <p class="text-gray-500 dark:text-[#94A3B8]">Track your payments and subscription activity</p>
        </div>

        @if($transactions->count() > 0)
            <div class="section-card overflow-x-auto">
                <table class="w-full text-left min-w-[600px]">
                    <thead>
                        <tr>
                            <th class="py-4 px-4 text-xs font-bold text-gray-500 dark:text-[#94A3B8] uppercase tracking-wider border-b border-gray-200 dark:border-white/10">Date</th>
                            <th class="py-4 px-4 text-xs font-bold text-gray-500 dark:text-[#94A3B8] uppercase tracking-wider border-b border-gray-200 dark:border-white/10">Description</th>
                            <th class="py-4 px-4 text-xs font-bold text-gray-500 dark:text-[#94A3B8] uppercase tracking-wider border-b border-gray-200 dark:border-white/10">Price</th>
                            <th class="py-4 px-4 text-xs font-bold text-gray-500 dark:text-[#94A3B8] uppercase tracking-wider border-b border-gray-200 dark:border-white/10">Gateway</th>
                            <th class="py-4 px-4 text-xs font-bold text-gray-500 dark:text-[#94A3B8] uppercase tracking-wider border-b border-gray-200 dark:border-white/10">Status</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200 dark:divide-white/10">
                        @foreach($transactions as $tx)
                        <tr class="hover:bg-gray-50 dark:hover:bg-white/5 transition-colors">
                            <td class="py-4 px-4 text-gray-900 dark:text-white">{{ $tx->created_at->format('M d, Y') }}</td>
                            <td class="py-4 px-4 text-gray-900 dark:text-white">Plan: <strong>{{ $tx->plan->name }}</strong></td>
                            <td class="py-4 px-4 font-bold text-gray-900 dark:text-white">${{ number_format($tx->amount, 2) }}</td>
                            <td class="py-4 px-4 text-xs font-mono uppercase tracking-wider text-gray-500 dark:text-[#94A3B8]">{{ $tx->gateway }}</td>
                            <td class="py-4 px-4">
                                <span class="status-pill {{ $tx->status == 'SUCCESS' ? 'bg-green-50 dark:bg-green-500/10 text-green-600 dark:text-green-500 border border-green-200 dark:border-green-500/20' : ($tx->status == 'PENDING' ? 'bg-yellow-50 dark:bg-yellow-500/10 text-yellow-600 dark:text-yellow-500 border border-yellow-200 dark:border-yellow-500/20' : 'bg-red-50 dark:bg-red-500/10 text-red-600 dark:text-red-500 border border-red-200 dark:border-red-500/20') }}">
                                    {{ $tx->status }}
                                </span>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            <div class="mt-6 flex justify-center">
                {{ $transactions->links() }}
            </div>
        @else
            <div class="section-card text-center py-16">
                <div class="inline-flex items-center justify-center w-20 h-20 bg-gray-50 dark:bg-white/5 rounded-2xl mb-6">
                    <i data-feather="credit-card" class="w-10 h-10 text-gray-400"></i>
                </div>
                <h2 class="text-3xl font-bold mb-4">No Transactions Yet</h2>
                <p class="text-gray-500 dark:text-[#94A3B8] text-lg mb-8">When you purchase a plan, your receipts will appear here.</p>
                <a href="/#pricing" class="btn-primary inline-block py-4 px-10 text-lg rounded-xl shadow-md">Browse Plans</a>
            </div>
        @endif
    </div>
    <script>
        document.addEventListener('alpine:initialized', () => {
             feather.replace();
        });
        feather.replace();
    </script>
</body>
</html>
