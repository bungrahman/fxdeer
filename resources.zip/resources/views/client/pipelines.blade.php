<!DOCTYPE html>
<html lang="en" x-data="{ darkMode: localStorage.getItem('darkMode') === 'true', sidebarOpen: false }" x-init="$watch('darkMode', val => localStorage.setItem('darkMode', val))" :class="{ 'dark': darkMode }">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Pipelines - FXDeer</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/feather-icons"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body :class="{ 'overflow-hidden md:overflow-auto': sidebarOpen }">
    <!-- Mobile Sidebar Overlay -->
    <div x-show="sidebarOpen" x-transition.opacity class="fixed inset-0 bg-black/50 z-30 md:hidden" @click="sidebarOpen = false"></div>

    <div class="sidebar" :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'">
        <div class="flex items-center justify-between mb-8">
            <a href="/" class="logo flex items-center gap-2"><i data-feather="terminal" class="text-[#FF2D20]"></i> FXDeer</a>
            <button @click="sidebarOpen = false" class="md:hidden text-gray-500 hover:text-gray-900 dark:hover:text-white">
                <i data-feather="x"></i>
            </button>
        </div>

        <div class="nav-links flex flex-col gap-2">
            <a href="{{ route('client.dashboard') }}" class="nav-link"><i data-feather="grid"></i> Dashboard</a>
            <a href="{{ route('client.pipelines') }}" class="nav-link active"><i data-feather="settings"></i> My Pipelines</a>
            <a href="{{ route('client.billing') }}" class="nav-link"><i data-feather="credit-card"></i> Billing</a>
        </div>
        
        <div class="mt-auto">
            <form action="{{ route('logout') }}" method="POST">
                @csrf
                <button type="submit" class="nav-link w-full border-none bg-transparent cursor-pointer text-left">
                    <i data-feather="log-out"></i> Logout
                </button>
            </form>
        </div>
    </div>

    <div class="main-content">
        <!-- Top Navigation Area for Mobile & Dark Mode -->
        <div class="flex justify-between items-center mb-8">
            <div class="flex items-center gap-4">
                <button @click="sidebarOpen = true" class="md:hidden p-2 rounded-lg bg-white dark:bg-[#17171a]/70 border border-gray-200 dark:border-white/10 text-gray-600 dark:text-gray-300">
                    <i data-feather="menu"></i>
                </button>
                <div class="hidden md:block">
                    <h1 class="text-2xl font-bold">My News Pipelines</h1>
                </div>
            </div>

            <button @click="darkMode = !darkMode" class="p-2 rounded-full bg-white dark:bg-[#17171a]/70 border border-gray-200 dark:border-white/10 text-gray-600 dark:text-gray-300 transition-colors hover:bg-gray-50 dark:hover:bg-white/10">
                <i x-show="!darkMode" data-feather="moon" style="display: none;" class="w-5 h-5"></i>
                <i x-show="darkMode" data-feather="sun" style="display: none;" class="w-5 h-5"></i>
            </button>
        </div>

        <div class="mb-8 md:hidden">
            <h1 class="text-2xl font-bold">My News Pipelines</h1>
            <p class="text-gray-500 dark:text-[#94A3B8]">Detailed configuration of your automated news delivery</p>
        </div>

        @if($user->activeSubscription)
            @php $plan = $user->activeSubscription->plan; @endphp
            
            <div class="section-card">
                <div class="flex justify-between items-center mb-6">
                    <h3 class="text-xl font-bold flex items-center gap-2"><i data-feather="activity" class="text-[#FF2D20]"></i> Active Pipelines</h3>
                    <span class="status-pill bg-green-50 dark:bg-green-500/10 text-green-600 dark:text-green-500 border border-green-200 dark:border-green-500/20">Plan: {{ $plan->name }}</span>
                </div>

                <div class="space-y-4">
                    <div class="flex justify-between items-center p-4 bg-gray-50 dark:bg-white/5 border border-gray-200 dark:border-white/10 rounded-2xl">
                        <span class="font-medium text-gray-900 dark:text-white">Pipeline A: Daily Market Outlook</span>
                        <span class="status-pill {{ $plan->daily_outlook ? 'bg-green-50 dark:bg-green-500/10 text-green-600 dark:text-green-500 border border-green-200 dark:border-green-500/20' : 'bg-gray-100 dark:bg-white/5 text-gray-500 border border-gray-200 dark:border-white/10' }}">{{ $plan->daily_outlook ? 'ACTIVE' : 'DISABLED' }}</span>
                    </div>
                    <div class="flex justify-between items-center p-4 bg-gray-50 dark:bg-white/5 border border-gray-200 dark:border-white/10 rounded-2xl">
                        <span class="font-medium text-gray-900 dark:text-white">Pipeline B: Upcoming Event Alerts</span>
                        <span class="status-pill {{ $plan->upcoming_event_alerts ? 'bg-green-50 dark:bg-green-500/10 text-green-600 dark:text-green-500 border border-green-200 dark:border-green-500/20' : 'bg-gray-100 dark:bg-white/5 text-gray-500 border border-gray-200 dark:border-white/10' }}">{{ $plan->upcoming_event_alerts ? 'ACTIVE' : 'DISABLED' }}</span>
                    </div>
                    <div class="flex justify-between items-center p-4 bg-gray-50 dark:bg-white/5 border border-gray-200 dark:border-white/10 rounded-2xl">
                        <span class="font-medium text-gray-900 dark:text-white">Pipeline C: Post-Event Reactions</span>
                        <span class="status-pill {{ $plan->post_event_reaction ? 'bg-green-50 dark:bg-green-500/10 text-green-600 dark:text-green-500 border border-green-200 dark:border-green-500/20' : 'bg-gray-100 dark:bg-white/5 text-gray-500 border border-gray-200 dark:border-white/10' }}">{{ $plan->post_event_reaction ? 'ACTIVE' : 'DISABLED' }}</span>
                    </div>
                </div>
            </div>

            <div class="section-card">
                <h3 class="text-xl font-bold mb-2 flex items-center gap-2"><i data-feather="map" class="text-[#FF2D20]"></i> Delivery Metadata</h3>
                <p class="text-gray-500 dark:text-[#94A3B8] text-sm mb-6">These endpoints are used by n8n to deliver your news automations.</p>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="bg-gray-50 dark:bg-[#111114] p-6 rounded-2xl border border-gray-200 dark:border-white/10">
                        <div class="text-xs text-gray-500 dark:text-[#94A3B8] font-bold mb-2 uppercase tracking-wider">Telegram Chat ID</div>
                        <div class="font-mono text-[#FF2D20] break-all">{{ $plan->telegram_chat_id ?? 'Not Set' }}</div>
                    </div>
                    <div class="bg-gray-50 dark:bg-[#111114] p-6 rounded-2xl border border-gray-200 dark:border-white/10">
                        <div class="text-xs text-gray-500 dark:text-[#94A3B8] font-bold mb-2 uppercase tracking-wider">Tags Filter</div>
                        <div class="font-mono text-[#FF2D20] break-all">{{ $plan->tags ?? 'Default' }}</div>
                    </div>
                    <div class="bg-gray-50 dark:bg-[#111114] p-6 rounded-2xl border border-gray-200 dark:border-white/10">
                        <div class="text-xs text-gray-500 dark:text-[#94A3B8] font-bold mb-2 uppercase tracking-wider">Hashtags</div>
                        <div class="font-mono text-[#FF2D20] text-sm break-all">{{ $plan->hashtags ?? 'None' }}</div>
                    </div>
                    <div class="bg-gray-50 dark:bg-[#111114] p-6 rounded-2xl border border-gray-200 dark:border-white/10">
                        <div class="text-xs text-gray-500 dark:text-[#94A3B8] font-bold mb-2 uppercase tracking-wider">Delivery Channels</div>
                        <div class="text-gray-900 dark:text-white font-medium">
                            {{ $plan->enable_telegram ? 'Telegram' : '' }}
                            {{ $plan->enable_blotato ? ', Blotato' : '' }}
                            {{ $plan->enable_email ? ', Email' : '' }}
                        </div>
                    </div>
                </div>
            </div>

            <div class="space-y-8 mb-8">
                <!-- Language Settings Card -->
                <div class="section-card !mb-0">
                    <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-4">
                        <div class="flex items-center gap-3">
                            <i data-feather="globe" class="text-[#FF2D20]"></i>
                            <h3 class="text-xl font-bold m-0">Language Settings</h3>
                        </div>
                        <span class="status-pill inline-block bg-red-50 dark:bg-red-500/10 text-[#FF2D20]">Default: {{ strtoupper($user->default_language) }}</span>
                    </div>
                    <p class="text-gray-500 dark:text-[#94A3B8] text-sm mb-6">Choose your preferred language for news delivery and alerts.</p>
                    
                    <form action="{{ route('client.settings.language') }}" method="POST" class="flex flex-col md:flex-row gap-4">
                        @csrf
                        <select name="default_language" class="input-field cursor-pointer py-3 appearance-none flex-1">
                            @foreach(\App\Models\Setting::getSupportedLanguages() as $lang)
                                <option value="{{ $lang['code'] }}" {{ $user->default_language == $lang['code'] ? 'selected' : '' }} class="bg-white dark:bg-[#17171a] text-gray-900 dark:text-white">
                                    {{ $lang['name'] }} ({{ strtoupper($lang['code']) }})
                                </option>
                            @endforeach
                        </select>
                        <button type="submit" class="btn-primary py-3 px-8">Save</button>
                    </form>
                </div>

                <!-- Signal Alert Feature Status Card -->
                <div class="section-card !mb-0 border-l-4 {{ $plan->enable_signal_alert ? 'border-l-green-500' : 'border-l-gray-400' }} flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                    <div>
                        <div class="flex items-center gap-3 mb-2">
                            <i data-feather="zap" class="{{ $plan->enable_signal_alert ? 'text-green-500' : 'text-gray-400' }}"></i>
                            <h3 class="text-xl font-bold m-0">Signal Alert Status</h3>
                        </div>
                        <p class="text-gray-500 dark:text-[#94A3B8] text-sm m-0">Feature access based on your current <strong class="text-gray-900 dark:text-white">{{ $plan->name }}</strong> plan.</p>
                    </div>
                    @if($plan->enable_signal_alert)
                        <div class="status-pill bg-green-50 dark:bg-green-500/10 text-green-600 dark:text-green-500 border border-green-200 dark:border-green-500/20">ACTIVE</div>
                    @else
                        <div class="status-pill bg-gray-100 dark:bg-white/5 text-gray-500 dark:text-gray-400 border border-gray-200 dark:border-white/10">DISABLED</div>
                    @endif
                </div>
            </div>

            @if($plan->enable_signal_alert)
            <div class="section-card border-[#FF2D20] dark:border-[#FF2D20]/30 bg-red-50/30 dark:bg-red-500/5">
                <div class="flex items-center gap-3 mb-6">
                    <i data-feather="settings" class="text-[#FF2D20]"></i>
                    <h3 class="text-xl font-bold m-0">Signal Bot Configuration</h3>
                </div>
                <form action="{{ route('client.settings.bot') }}" method="POST">
                    @csrf
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-gray-500 dark:text-[#94A3B8] text-sm mb-2">Signal Bot Token</label>
                            <input type="text" name="signal_bot_token" value="{{ $user->signal_bot_token }}" placeholder="123456:ABC..." class="input-field">
                        </div>
                        <div>
                            <label class="block text-gray-500 dark:text-[#94A3B8] text-sm mb-2">Signal Telegram Chat</label>
                            <input type="text" name="signal_telegram_chat" value="{{ $user->signal_telegram_chat }}" placeholder="-100..." class="input-field">
                        </div>
                    </div>
                    <button type="submit" class="btn-primary mt-6">Save Bot Settings</button>
                </form>
            </div>
            @endif
        @else
            <div class="section-card text-center py-16">
                <div class="inline-flex items-center justify-center w-20 h-20 bg-gray-50 dark:bg-white/5 rounded-2xl mb-6">
                    <i data-feather="slash" class="w-10 h-10 text-gray-400"></i>
                </div>
                <h2 class="text-3xl font-bold mb-4">No Active Subscription</h2>
                <p class="text-gray-500 dark:text-[#94A3B8] text-lg mb-8">Subscribe to a plan to activate your news pipelines.</p>
                <a href="/#pricing" class="btn-primary inline-block py-4 px-10 text-lg rounded-xl shadow-md">View Plans</a>
            </div>
        @endif
    </div>
    <script>
        document.addEventListener('alpine:initialized', () => {
             feather.replace();
        });
        feather.replace();
    </script>
</body>
</html>
