<!DOCTYPE html>
<html lang="en" x-data="{ darkMode: localStorage.getItem('darkMode') === 'true', sidebarOpen: false }" x-init="$watch('darkMode', val => localStorage.setItem('darkMode', val))" :class="{ 'dark': darkMode }">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Client Dashboard - FXDeer</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/feather-icons"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body :class="{ 'overflow-hidden md:overflow-auto': sidebarOpen }">
    <!-- Mobile Sidebar Overlay -->
    <div x-show="sidebarOpen" x-transition.opacity class="fixed inset-0 bg-black/50 z-30 md:hidden" @click="sidebarOpen = false"></div>

    <div class="sidebar" :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'">
        <div class="flex items-center justify-between mb-8">
            <a href="/" class="logo flex items-center gap-2"><i data-feather="terminal" class="text-[#FF2D20]"></i> FXDeer</a>
            <button @click="sidebarOpen = false" class="md:hidden text-gray-500 hover:text-gray-900 dark:hover:text-white">
                <i data-feather="x"></i>
            </button>
        </div>

        <div class="nav-links flex flex-col gap-2">
            <a href="{{ route('client.dashboard') }}" class="nav-link {{ Route::is('client.dashboard') ? 'active' : '' }}"><i data-feather="grid"></i> Dashboard</a>
            <a href="{{ route('client.pipelines') }}" class="nav-link {{ Route::is('client.pipelines') ? 'active' : '' }}"><i data-feather="settings"></i> My Pipelines</a>
            <a href="{{ route('client.billing') }}" class="nav-link {{ Route::is('client.billing') ? 'active' : '' }}"><i data-feather="credit-card"></i> Billing</a>
        </div>
        
        <div class="mt-auto">
            <form action="{{ route('logout') }}" method="POST">
                @csrf
                <button type="submit" class="nav-link w-full border-none bg-transparent cursor-pointer text-left">
                    <i data-feather="log-out"></i> Logout
                </button>
            </form>
        </div>
    </div>

    <div class="main-content">
        <!-- Top Navigation Area for Mobile & Dark Mode -->
        <div class="flex justify-between items-center mb-8">
            <div class="flex items-center gap-4">
                <button @click="sidebarOpen = true" class="md:hidden p-2 rounded-lg bg-white dark:bg-[#17171a]/70 border border-gray-200 dark:border-white/10 text-gray-600 dark:text-gray-300">
                    <i data-feather="menu"></i>
                </button>
                <div class="hidden md:flex items-center gap-4">
                    <h1 class="text-2xl font-bold">Welcome, {{ Auth::user()->email }}</h1>
                </div>
            </div>

            <div class="flex items-center gap-4">
                <!-- Dark Mode Toggle -->
                <button @click="darkMode = !darkMode" class="p-2 rounded-full bg-white dark:bg-[#17171a]/70 border border-gray-200 dark:border-white/10 text-gray-600 dark:text-gray-300 transition-colors hover:bg-gray-50 dark:hover:bg-white/10">
                    <i x-show="!darkMode" data-feather="moon" style="display: none;" class="w-5 h-5"></i>
                    <i x-show="darkMode" data-feather="sun" style="display: none;" class="w-5 h-5"></i>
                </button>
                <div class="w-10 h-10 bg-[#FF2D20] text-white rounded-full flex items-center justify-center font-bold">
                    {{ strtoupper(substr(Auth::user()->email, 0, 1)) }}
                </div>
            </div>
        </div>

        <div class="mb-8 md:hidden">
            <h1 class="text-2xl font-bold">Welcome, {{ Auth::user()->email }}</h1>
            <p class="text-gray-500 dark:text-[#94A3B8]">Manage your automated news flows</p>
        </div>

        @if(session('success'))
            <div class="bg-green-50 dark:bg-green-500/10 text-green-600 dark:text-green-500 p-4 rounded-xl mb-8 border border-green-200 dark:border-green-500/20">
                {{ session('success') }}
            </div>
        @endif

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <div class="section-card !mb-0">
                <div class="text-gray-500 dark:text-[#94A3B8] text-sm mb-2">Active Plan</div>
                <div class="text-3xl font-bold text-[#FF2D20]">{{ Auth::user()->activeSubscription->plan->name ?? 'NO ACTIVE PLAN' }}</div>
                @if(!Auth::user()->activeSubscription)
                    <a href="/#pricing" class="btn-primary mt-6 block text-center">Choose a Plan</a>
                @endif
            </div>

            <div class="section-card !mb-0">
                <div class="text-gray-500 dark:text-[#94A3B8] text-sm mb-2">Remaining Alerts Today</div>
                <div class="text-3xl font-bold text-gray-900 dark:text-white">
                    {{ ($user->activeSubscription->plan->max_alerts_per_day ?? 0) - $usageToday }} / {{ $user->activeSubscription->plan->max_alerts_per_day ?? 0 }}
                </div>
            </div>
        </div>

        <div class="section-card mb-8">
            <h3 class="text-xl font-bold mb-6">Pipeline Status</h3>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div class="bg-gray-50 dark:bg-white/5 border border-gray-200 dark:border-white/10 p-4 rounded-2xl text-center">
                    <div class="text-gray-500 dark:text-[#94A3B8] text-xs font-bold mb-2">DAILY OUTLOOK</div>
                    <div class="font-bold text-gray-900 dark:text-white">{{ (Auth::user()->activeSubscription->plan->daily_outlook ?? false) ? 'ENABLED' : 'DISABLED' }}</div>
                </div>
                <div class="bg-gray-50 dark:bg-white/5 border border-gray-200 dark:border-white/10 p-4 rounded-2xl text-center">
                    <div class="text-gray-500 dark:text-[#94A3B8] text-xs font-bold mb-2">UPCOMING ALERTS</div>
                    <div class="font-bold text-gray-900 dark:text-white">{{ (Auth::user()->activeSubscription->plan->upcoming_event_alerts ?? false) ? 'ENABLED' : 'DISABLED' }}</div>
                </div>
            </div>
        </div>

        @php
            $user = Auth::user();
            $subscription = $user->activeSubscription;
            $plan = $subscription ? $subscription->plan : null;
        @endphp

        @if($plan)
            <div class="space-y-8 mb-8">
                <!-- Language Settings Card -->
                <div class="section-card !mb-0">
                    <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-4">
                        <div class="flex items-center gap-3">
                            <i data-feather="globe" class="text-[#FF2D20]"></i>
                            <h3 class="text-xl font-bold m-0">Language Settings</h3>
                        </div>
                        <span class="status-pill inline-block bg-red-50 dark:bg-red-500/10 text-[#FF2D20]">Default: {{ strtoupper($user->default_language) }}</span>
                    </div>
                    <p class="text-gray-500 dark:text-[#94A3B8] text-sm mb-6">Choose your preferred language for news delivery and alerts.</p>
                    
                    <form action="{{ route('client.settings.language') }}" method="POST" class="flex flex-col md:flex-row gap-4">
                        @csrf
                        <select name="default_language" class="input-field cursor-pointer py-3 appearance-none flex-1">
                            @foreach(\App\Models\Setting::getSupportedLanguages() as $lang)
                                <option value="{{ $lang['code'] }}" {{ $user->default_language == $lang['code'] ? 'selected' : '' }} class="bg-white dark:bg-[#17171a] text-gray-900 dark:text-white">
                                    {{ $lang['name'] }} ({{ strtoupper($lang['code']) }})
                                </option>
                            @endforeach
                        </select>
                        <button type="submit" class="btn-primary py-3 px-8">Save</button>
                    </form>
                </div>

                @if($plan->enable_signal_alert)
                <!-- Signal Bot Configuration Card -->
                <div class="section-card !mb-0 border-[#FF2D20] dark:border-[#FF2D20]/30 bg-red-50/30 dark:bg-red-500/5">
                    <div class="flex items-center gap-3 mb-6">
                        <i data-feather="settings" class="text-[#FF2D20]"></i>
                        <h3 class="text-xl font-bold m-0">Signal Bot Configuration</h3>
                    </div>
                    <form action="{{ route('client.settings.bot') }}" method="POST">
                        @csrf
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-gray-500 dark:text-[#94A3B8] text-sm mb-2">Signal Bot Token</label>
                                <input type="text" name="signal_bot_token" value="{{ $user->signal_bot_token }}" placeholder="123456:ABC..." class="input-field">
                            </div>
                            <div>
                                <label class="block text-gray-500 dark:text-[#94A3B8] text-sm mb-2">Signal Telegram Chat</label>
                                <input type="text" name="signal_telegram_chat" value="{{ $user->signal_telegram_chat }}" placeholder="-100..." class="input-field">
                            </div>
                        </div>
                        <button type="submit" class="btn-primary mt-6">Save Bot Settings</button>
                    </form>
                </div>
                @endif
            </div>
        @endif
    </div>

    <script>
        document.addEventListener('alpine:initialized', () => {
             feather.replace();
        });
        feather.replace();
    </script>
</body>
</html>
