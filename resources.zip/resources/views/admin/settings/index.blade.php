@extends('layouts.admin')

@section('title', 'System Settings')

@section('content')
<header>
    <h2>System Settings</h2>
    <div style="font-size: 0.9rem; color: var(--text-dim);">Global configuration & API management</div>
</header>

@if(session('success'))
    <div class="bg-green-50 dark:bg-green-500/10 text-green-600 dark:text-green-500 p-4 rounded-xl mb-8 border border-green-200 dark:border-green-500/20">
        {{ session('success') }}
    </div>
@endif

<form action="{{ route('admin.settings.update') }}" method="POST">
    @csrf
    
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem;">
        <!-- API Configuration -->
        <div class="section-card">
            <div class="section-title"><i data-feather="key"></i> API Configuration</div>
            
            <div style="margin-bottom: 1.5rem;">
                <label style="display: block; color: var(--text-dim); margin-bottom: 0.5rem; font-size: 0.85rem;">Stripe Secret Key</label>
                <input type="password" name="stripe_secret" value="{{ $settings['stripe_secret'] ?? '' }}" style="width: 100%; background: rgba(0,0,0,0.3); border: 1px solid var(--glass-border); color: white; padding: 0.8rem; border-radius: 10px; outline: none;" placeholder="sk_test_...">
            </div>

            <div style="margin-bottom: 1.5rem;">
                <label style="display: block; color: var(--text-dim); margin-bottom: 0.5rem; font-size: 0.85rem;">Stripe Webhook Secret</label>
                <input type="password" name="stripe_webhook_secret" value="{{ $settings['stripe_webhook_secret'] ?? '' }}" style="width: 100%; background: rgba(0,0,0,0.3); border: 1px solid var(--glass-border); color: white; padding: 0.8rem; border-radius: 10px; outline: none;" placeholder="whsec_...">
            </div>

            <div style="border-top: 1px solid var(--glass-border); padding-top: 1.5rem; margin-top: 2rem;">
                <div class="section-title" style="font-size: 1rem; margin-bottom: 1.5rem;"><i data-feather="credit-card"></i> Duitku Config</div>
                <div style="margin-bottom: 1rem;">
                    <label style="display: block; color: var(--text-dim); margin-bottom: 0.5rem; font-size: 0.85rem;">Merchant Code</label>
                    <input type="text" name="duitku_merchant_code" value="{{ $settings['duitku_merchant_code'] ?? '' }}" style="width: 100%; background: rgba(0,0,0,0.3); border: 1px solid var(--glass-border); color: white; padding: 0.8rem; border-radius: 10px; outline: none;" placeholder="DXXXX">
                </div>
                <div style="margin-bottom: 1rem;">
                    <label style="display: block; color: var(--text-dim); margin-bottom: 0.5rem; font-size: 0.85rem;">API Key</label>
                    <input type="password" name="duitku_api_key" value="{{ $settings['duitku_api_key'] ?? '' }}" style="width: 100%; background: rgba(0,0,0,0.3); border: 1px solid var(--glass-border); color: white; padding: 0.8rem; border-radius: 10px; outline: none;" placeholder="Standard / Callback API Key">
                </div>
                <div style="margin-bottom: 1rem;">
                    <label style="display: block; color: var(--text-dim); margin-bottom: 0.5rem; font-size: 0.85rem;">URL Callback (Copy to Duitku Dashboard)</label>
                    <input type="text" value="{{ url('/api/duitku/callback') }}" style="width: 100%; background: rgba(255,45,32,0.05); border: 1px dashed var(--primary); color: var(--primary); padding: 0.8rem; border-radius: 10px; outline: none; font-family: monospace; font-size: 0.8rem;" readonly>
                </div>
            </div>

            <div style="border-top: 1px solid var(--glass-border); padding-top: 1.5rem; margin-top: 2rem;">
                <div class="section-title" style="font-size: 1rem; margin-bottom: 1.5rem;"><i data-feather="globe"></i> PayPal Config</div>
                <div style="margin-bottom: 1rem;">
                    <label style="display: block; color: var(--text-dim); margin-bottom: 0.5rem; font-size: 0.85rem;">Client ID</label>
                    <input type="text" name="paypal_client_id" value="{{ $settings['paypal_client_id'] ?? '' }}" style="width: 100%; background: rgba(0,0,0,0.3); border: 1px solid var(--glass-border); color: white; padding: 0.8rem; border-radius: 10px; outline: none;" placeholder="AXxxxx...">
                </div>
                <div style="margin-bottom: 1rem;">
                    <label style="display: block; color: var(--text-dim); margin-bottom: 0.5rem; font-size: 0.85rem;">Secret</label>
                    <input type="password" name="paypal_secret" value="{{ $settings['paypal_secret'] ?? '' }}" style="width: 100%; background: rgba(0,0,0,0.3); border: 1px solid var(--glass-border); color: white; padding: 0.8rem; border-radius: 10px; outline: none;" placeholder="EPxxxx...">
                </div>
            </div>
        </div>

        <!-- System behavior -->
        <div class="section-card">
            <div class="section-title"><i data-feather="sliders"></i> System Overrides</div>
            
            <div style="margin-bottom: 1.5rem; display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <h5 style="font-size: 0.9rem; margin-bottom: 0.2rem;">Maintenance Mode</h5>
                    <p style="color: var(--text-dim); font-size: 0.75rem;">Restrict access to admin dashboard only.</p>
                </div>
                <label class="switch">
                    <input type="hidden" name="maintenance_mode" value="0">
                    <input type="checkbox" name="maintenance_mode" value="1" {{ ($settings['maintenance_mode'] ?? '0') == '1' ? 'checked' : '' }}>
                    <span class="slider"></span>
                </label>
            </div>

            <!-- Global Kill-Switches -->
            <div style="border-top: 1px solid var(--glass-border); padding-top: 1.5rem; margin-top: 2rem;">
                <div class="section-title" style="font-size: 1rem; margin-bottom: 1.5rem;"><i data-feather="shield"></i> Global Kill-Switches</div>
                
                <div style="margin-bottom: 1.5rem; display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <h5 style="font-size: 0.9rem; margin-bottom: 0.2rem;">Emergency Global Pause</h5>
                        <p style="color: var(--text-dim); font-size: 0.75rem;">Instantly stop ALL news distribution.</p>
                    </div>
                    <label class="switch">
                        <input type="hidden" name="emergency_pause" value="0">
                        <input type="checkbox" name="emergency_pause" value="1" {{ ($settings['emergency_pause'] ?? '0') == '1' ? 'checked' : '' }}>
                        <span class="slider"></span>
                    </label>
                </div>

                <div style="margin-bottom: 1.5rem; display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <h5 style="font-size: 0.9rem; margin-bottom: 0.2rem;">Pipeline A (High Priority) Pause</h5>
                        <p style="color: var(--text-dim); font-size: 0.75rem;">Instantly pause Pipeline A for all users.</p>
                    </div>
                    <label class="switch">
                        <input type="hidden" name="kill_switch_pipeline_a" value="0">
                        <input type="checkbox" name="kill_switch_pipeline_a" value="1" {{ ($settings['kill_switch_pipeline_a'] ?? '0') == '1' ? 'checked' : '' }}>
                        <span class="slider"></span>
                    </label>
                </div>

                <div style="margin-bottom: 1.5rem; display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <h5 style="font-size: 0.9rem; margin-bottom: 0.2rem;">Pipeline B (Standard) Pause</h5>
                        <p style="color: var(--text-dim); font-size: 0.75rem;">Instantly pause Pipeline B for all users.</p>
                    </div>
                    <label class="switch">
                        <input type="hidden" name="kill_switch_pipeline_b" value="0">
                        <input type="checkbox" name="kill_switch_pipeline_b" value="1" {{ ($settings['kill_switch_pipeline_b'] ?? '0') == '1' ? 'checked' : '' }}>
                        <span class="slider"></span>
                    </label>
                </div>
            </div>
        </div>
    </div>

    <div style="margin-top: 2rem;">
        <div class="section-card">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
                <div class="section-title" style="margin-bottom: 0;"><i data-feather="globe"></i> Language Distribution Management</div>
                <button type="button" onclick="addLanguageRow()" class="status-pill" style="background: rgba(34, 197, 94, 0.1); color: #22c55e; border: 1px solid rgba(34, 197, 94, 0.2); cursor: pointer; padding: 0.5rem 1rem;">+ Add Language</button>
            </div>
            
            <p style="color: var(--text-dim); font-size: 0.85rem; margin-bottom: 1.5rem;">Define supported languages and their dedicated Telegram bots for standardized pipelines.</p>

            <div id="language-container">
                @php
                    $supportedLangs = \App\Models\Setting::getSupportedLanguages();
                @endphp
                
                @if(count($supportedLangs) > 0)
                    @foreach($supportedLangs as $index => $lang)
                        <div class="lang-row" style="display: grid; grid-template-columns: 200px 1fr 1fr 50px; gap: 1rem; margin-bottom: 1rem; align-items: end;">
                            <div>
                                <label style="display: block; color: var(--text-dim); font-size: 0.7rem; margin-bottom: 0.3rem;">Language</label>
                                <select name="supported_languages[{{ $index }}][code]" onchange="updateLangName(this, {{ $index }})" style="width: 100%; background: rgba(0,0,0,0.3); border: 1px solid var(--glass-border); color: white; padding: 0.6rem; border-radius: 8px; outline: none; font-size: 0.85rem;" required>
                                    @foreach(['en' => 'English', 'id' => 'Indonesian', 'ja' => 'Japanese', 'ko' => 'Korean', 'zh' => 'Chinese', 'es' => 'Spanish', 'fr' => 'French', 'de' => 'German', 'ru' => 'Russian', 'pt' => 'Portuguese', 'vi' => 'Vietnamese', 'th' => 'Thai'] as $code => $name)
                                        <option value="{{ $code }}" {{ ($lang['code'] ?? '') == $code ? 'selected' : '' }} data-name="{{ $name }}">{{ $name }} ({{ strtoupper($code) }})</option>
                                    @endforeach
                                </select>
                                <input type="hidden" name="supported_languages[{{ $index }}][name]" id="lang_name_{{ $index }}" value="{{ $lang['name'] ?? 'English' }}">
                            </div>
                            <div>
                                <label style="display: block; color: var(--text-dim); font-size: 0.7rem; margin-bottom: 0.3rem;">Bot Token</label>
                                <input type="text" name="supported_languages[{{ $index }}][bot_token]" value="{{ $lang['bot_token'] ?? '' }}" style="width: 100%; background: rgba(0,0,0,0.3); border: 1px solid var(--glass-border); color: white; padding: 0.6rem; border-radius: 8px; outline: none; font-size: 0.85rem;" placeholder="Bot Token">
                            </div>
                            <div>
                                <label style="display: block; color: var(--text-dim); font-size: 0.7rem; margin-bottom: 0.3rem;">Chat ID</label>
                                <input type="text" name="supported_languages[{{ $index }}][chat_id]" value="{{ $lang['chat_id'] ?? '' }}" style="width: 100%; background: rgba(0,0,0,0.3); border: 1px solid var(--glass-border); color: white; padding: 0.6rem; border-radius: 8px; outline: none; font-size: 0.85rem;" placeholder="Chat ID">
                            </div>
                            <button type="button" onclick="this.parentElement.remove()" style="background: rgba(255,45,32,0.1); border: none; color: var(--primary); padding: 0.6rem; border-radius: 8px; cursor: pointer;"><i data-feather="trash-2" style="width: 16px; height: 16px;"></i></button>
                        </div>
                    @endforeach
                @endif
            </div>
        </div>
    </div>

    <script>
        let langIndex = {{ count($supportedLangs) }};
        const isoLangs = {'en': 'English', 'id': 'Indonesian', 'ja': 'Japanese', 'ko': 'Korean', 'zh': 'Chinese', 'es': 'Spanish', 'fr': 'French', 'de' : 'German', 'ru': 'Russian', 'pt': 'Portuguese', 'vi': 'Vietnamese', 'th': 'Thai'};

        function updateLangName(select, index) {
            const name = select.options[select.selectedIndex].getAttribute('data-name');
            document.getElementById(`lang_name_${index}`).value = name;
        }

        function addLanguageRow() {
            const container = document.getElementById('language-container');
            const row = document.createElement('div');
            row.className = 'lang-row';
            row.style = 'display: grid; grid-template-columns: 200px 1fr 1fr 50px; gap: 1rem; margin-bottom: 1rem; align-items: end;';
            
            let optionsHtml = '';
            for (const [code, name] of Object.entries(isoLangs)) {
                optionsHtml += `<option value="${code}" data-name="${name}">${name} (${code.toUpperCase()})</option>`;
            }

            row.innerHTML = `
                <div>
                    <label style="display: block; color: var(--text-dim); font-size: 0.7rem; margin-bottom: 0.3rem;">Language</label>
                    <select name="supported_languages[${langIndex}][code]" onchange="updateLangName(this, ${langIndex})" style="width: 100%; background: rgba(0,0,0,0.3); border: 1px solid var(--glass-border); color: white; padding: 0.6rem; border-radius: 8px; outline: none; font-size: 0.85rem;" required>
                        ${optionsHtml}
                    </select>
                    <input type="hidden" name="supported_languages[${langIndex}][name]" id="lang_name_${langIndex}" value="English">
                </div>
                <div>
                    <label style="display: block; color: var(--text-dim); font-size: 0.7rem; margin-bottom: 0.3rem;">Bot Token</label>
                    <input type="text" name="supported_languages[${langIndex}][bot_token]" style="width: 100%; background: rgba(0,0,0,0.3); border: 1px solid var(--glass-border); color: white; padding: 0.6rem; border-radius: 8px; outline: none; font-size: 0.85rem;" placeholder="Bot Token">
                </div>
                <div>
                    <label style="display: block; color: var(--text-dim); font-size: 0.7rem; margin-bottom: 0.3rem;">Chat ID</label>
                    <input type="text" name="supported_languages[${langIndex}][chat_id]" style="width: 100%; background: rgba(0,0,0,0.3); border: 1px solid var(--glass-border); color: white; padding: 0.6rem; border-radius: 8px; outline: none; font-size: 0.85rem;" placeholder="Chat ID">
                </div>
                <button type="button" onclick="this.parentElement.remove()" style="background: rgba(255,45,32,0.1); border: none; color: var(--primary); padding: 0.6rem; border-radius: 8px; cursor: pointer;"><i data-feather="trash-2" style="width: 16px; height: 16px;"></i></button>
            `;
            container.appendChild(row);
            feather.replace();
            langIndex++;
        }
    </script>

    <style>
        .switch { position: relative; display: inline-block; width: 44px; height: 22px; }
        .switch input { opacity: 0; width: 0; height: 0; }
        .slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #333; transition: .4s; border-radius: 34px; }
        .slider:before { position: absolute; content: ""; height: 14px; width: 14px; left: 4px; bottom: 4px; background-color: white; transition: .4s; border-radius: 50%; }
        input:checked + .slider { background-color: var(--primary) !important; }
        input:checked + .slider:before { transform: translateX(22px); }
        input[name="maintenance_mode"]:checked + .slider { background-color: var(--warning) !important; }
    </style>

    <div style="margin-top: 2rem; display: flex; justify-content: flex-end;">
        <button type="submit" style="background: var(--primary); color: white; padding: 1rem 3rem; border-radius: 12px; border: none; font-weight: 700; cursor: pointer; transition: all 0.2s;">Save Global Settings</button>
    </div>
</form>
@endsection
