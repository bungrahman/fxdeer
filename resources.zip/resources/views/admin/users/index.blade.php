@extends('layouts.admin')

@section('title', 'Users Management')

@section('content')
<header>
    <h2>Users Management</h2>
    <div class="flex flex-col md:flex-row gap-4 items-center">
        <div class="stat-card" style="padding: 0.5rem 1rem; background: var(--card-bg); border: 1px solid var(--glass-border); border-radius: 12px; margin-bottom: 0;">
            <span style="color: var(--text-dim); font-size: 0.9rem;">Total: {{ $users->total() }}</span>
        </div>
        <a href="{{ route('admin.users.create') }}" class="status-pill inline-block btn-primary text-sm py-2 px-4">+ Add New User</a>
    </div>
</header>
 
@if(session('success'))
    <div class="bg-green-50 dark:bg-green-500/10 text-green-600 dark:text-green-500 p-4 rounded-xl mb-8 border border-green-200 dark:border-green-500/20">
        {{ session('success') }}
    </div>
@endif

<div class="section-card">
    <div class="section-title"><i data-feather="users"></i> Registered Users</div>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Email</th>
                <th>Plan</th>
                <th>Status</th>
                <th>Joined</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach($users as $user)
            <tr>
                <td class="text-gray-500 dark:text-gray-400">#{{ $user->id }}</td>
                <td class="font-medium">{{ $user->email }}</td>
                <td>
                    <span class="text-[#FF2D20]">{{ $user->activeSubscription->plan->name ?? 'No Plan' }}</span>
                </td>
                <td>
                    <span class="status-pill {{ $user->status == 'ACTIVE' ? 'status-active' : 'status-suspended' }}">{{ $user->status }}</span>
                </td>
                <td class="text-gray-500 dark:text-gray-400">{{ $user->created_at->format('M d, Y') }}</td>
                <td>
                    <div style="display: flex; gap: 0.5rem;">
                        <a href="{{ route('admin.users.edit', $user) }}" class="status-pill bg-white dark:bg-white/5 text-gray-700 dark:text-white border border-gray-200 dark:border-white/10 hover:bg-gray-50 dark:hover:bg-white/10 transition-colors cursor-pointer text-xs">Edit</a>
                        <form action="{{ route('admin.users.delete', $user) }}" method="POST" onsubmit="return confirm('Are you sure?')" style="display: inline;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="status-pill bg-red-50 dark:bg-red-500/10 text-red-600 dark:text-red-500 border border-red-200 dark:border-red-500/20 hover:bg-red-100 dark:hover:bg-red-500/20 transition-colors cursor-pointer text-xs">Delete</button>
                        </form>
                    </div>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
    
    <div style="margin-top: 2rem;">
        {{ $users->links() }}
    </div>
</div>
@endsection
